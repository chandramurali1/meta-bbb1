This layer depends on:

    URI: git://git.yoctoproject.org/poky.git
    branch: dunfell

    URI: git://git.openembedded.org/meta-openembedded
    branch: dunfell

    URI: https://github.com/meta-qt5/meta-qt5.git
    branch: dunfell

    URI: git://git.yoctoproject.org/meta-security.git
    branch: dunfell

    URI: https://github.com/jumpnow/meta-jumpnow.git
    branch: dunfell


Latest commits:

    poky dc38d5e494
    meta-openembedded de37512b2
    meta-qt5 0d8eb95
    meta-security c74cc97
    meta-jumpnow b399563


meta-bbb layer maintainer: Scott Ellis <scott@jumpnowtek.com>
