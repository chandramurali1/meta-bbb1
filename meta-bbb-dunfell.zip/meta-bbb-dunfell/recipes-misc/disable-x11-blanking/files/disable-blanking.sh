xset s off
xset -dpms
xset s noblank
